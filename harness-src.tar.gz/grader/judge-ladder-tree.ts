// A judge's sealed ladder directory read and held (contracts/competition.ts ProgramJudgeLadder): what a dev phase's
// provisional heat on a ladder plays against and rates by (grader/judge-heat.ts, the header's ladder). The worker's
// provisional heat, a regrade of its record, grade-local and the final kit's verification all read it here, as
// grader/worker.ts readJudgeTree reads the judge directory.
//
//   the seal         the ladder directory re-hashed (server/competitions/load.ts treeSha256) against the bundle's
//                    ladder.ladder_sha256, and the judge directory against judge_sha256: the image holds this bundle's
//                    ladder and judge, or nothing is read
//   the layout       PROGRAM_JUDGE_LADDER_CALIBRATION, a regular file, and at most PROGRAM_JUDGE_LADDER_RUNGS_DIR/ beside
//                    it, a flat directory of regular files (the rungs), none a judge anchor's twin and no two alike
//                    (server/competitions/load.ts ladderDirIssues held the same at load: this holds it again where it is
//                    read). The judge anchors are the regular files flat under <judge dir>/PROGRAM_JUDGE_ANCHORS_DIR/
//   the record       calibration.json is a calibration heat's record (grader/judge-heat.ts parseJudgeHeatRecord): format
//                    agent-fun/judge-heat/v3, stage `calibration`, that holds, stored as its canonical JSON byte for byte
//                    (judgeHeatRecordDigest), its sha256 the calibration_sha256 a ladder heat names
//   this judge's     the record's agent, judge_sha256, media and artifact are the bundle's, and its field is exactly the
//                    judge anchors and the rungs read here: judgeHeatField of no entries, these anchors and these rungs,
//                    each member's sha256, size, anchor files and rung files
//   the fit          judgeLadderFitOf: each member's fixed strength (Fixed9, sha256 order) and the dispersion phi
//
// A ladder that does not read or hold is refused (`{ refused }`): the bundle names a ladder the image does not hold, or
// one no heat can rate by. No retry mends that.

import { lstatSync, readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import {
  PROGRAM_JUDGE_ANCHORS_DIR,
  PROGRAM_JUDGE_LADDER_CALIBRATION,
  PROGRAM_JUDGE_LADDER_MAX,
  PROGRAM_JUDGE_LADDER_RUNGS_DIR,
  ProgramJudgeLadder,
  type ProgramJudgeT,
} from '../contracts/competition.ts';
import { Sha256Hex } from '../contracts/primitives.ts';
import { TreeDigestError, treeSha256 } from '../server/competitions/load.ts';
import { canonicalJson, compareCodeUnits, sha256Hex } from '../sim/canonical.ts';
import {
  JUDGE_HEAT_FORMAT_V3,
  JudgeHeatError,
  JudgeHeatLadder,
  judgeHeatField,
  judgeHeatRecordDigest,
  judgeLadderFitOf,
  parseJudgeHeatRecord,
  type JudgeFieldMemberT,
  type JudgeHeatLadderT,
  type JudgeHeatRecordT,
  type JudgeLadderStrengthT,
} from './judge-heat.ts';

/** A ladder member's file: its path under its directory (anchors/ or rungs/), its sha256 and its size in bytes. */
export interface JudgeLadderFileT {
  file: string;
  artifact_sha256: string;
  artifact_bytes: number;
}

/** A sealed ladder read and held (readJudgeLadder). */
export interface JudgeLadderInputs {
  /** The ladder directory's tree digest: the bundle's ladder.ladder_sha256. */
  ladder_sha256: string;
  /** The judge anchors, flat under <judge dir>/anchors/, in code-unit order of their names. */
  anchors: JudgeLadderFileT[];
  /** The rungs, flat under <ladder dir>/rungs/, in code-unit order of their names (none when the ladder has no rungs/). */
  rungs: JudgeLadderFileT[];
  /** The ladder's members, the calibration's field: the anchors and the rungs, one per artifact, in sha256 order. */
  members: JudgeFieldMemberT[];
  /** Every member's bytes, by sha256: what the judge reads. */
  artifacts: Map<string, Uint8Array>;
  /** The calibration heat's record, as calibration.json holds it. */
  calibration: JudgeHeatRecordT;
  /** calibration.json's sha256: its canonical JSON's (judgeHeatRecordDigest). */
  calibration_sha256: string;
  /** Every member's fixed strength in sha256 order (judgeLadderFitOf). */
  strengths: JudgeLadderStrengthT[];
  /** phi, Fixed9 (judgeLadderFitOf). */
  dispersion: string;
  /**
   * The setup's `ladder` block at the bundle's rounds, games and spread for an entry that is no ladder member (every
   * member's strength): judgeLadderBlock for another design, or an entry whose artifact is one.
   */
  ladder: JudgeHeatLadderT;
}

/** A ladder heat's adaptive design: its rounds, its games a round, the members a round spreads over. */
export interface JudgeLadderDesignT {
  rounds: number;
  games: number;
  spread: number;
}

/**
 * The setup's `ladder` block (grader/judge-heat.ts JudgeHeatLadder) for a provisional heat on the ladder `read`, with
 * the adaptive design `design` (a budget-short day's fewer rounds: grader/worker.ts) and `subject`, the entry's artifact
 * sha256: its strengths are every OTHER member's, so a subject that is a ladder member (an entry identical to an anchor
 * or a rung) is left out of them, as the heat's field merges it into that member. RangeError when the design is not
 * one a bundle's ladder may name (contracts/competition.ts ProgramJudgeLadder: rounds 0 to 8, games 1 to 8, spread 1 to
 * 4 and at most games); TypeError on a subject that is no sha256.
 */
export function judgeLadderBlock(read: Pick<JudgeLadderInputs, 'ladder_sha256' | 'calibration_sha256' | 'strengths' | 'dispersion'>, design: JudgeLadderDesignT, subject?: string): JudgeHeatLadderT {
  const parsed = ProgramJudgeLadder.safeParse({ dir: 'ladder', ladder_sha256: read.ladder_sha256, ...pick(design) });
  if (!parsed.success) {
    throw new RangeError(
      `the ladder design ${canonicalJson(pick(design))} is not one a bundle names (rounds 0 to ${PROGRAM_JUDGE_LADDER_MAX.rounds}, games 1 to ${PROGRAM_JUDGE_LADDER_MAX.games}, spread 1 to ${PROGRAM_JUDGE_LADDER_MAX.spread} and at most games): ${parsed.error.issues.map((i) => `${i.path.join('.') || '(ladder)'}: ${i.message}`).join('; ')}`,
    );
  }
  if (subject !== undefined && !Sha256Hex.safeParse(subject).success) throw new TypeError(`${JSON.stringify(subject)} is not an artifact's lowercase hex sha256`);
  return JudgeHeatLadder.parse({
    ladder_sha256: read.ladder_sha256,
    calibration_sha256: read.calibration_sha256,
    strengths: read.strengths.filter((s) => s.artifact_sha256 !== subject).map((s) => ({ ...s })),
    dispersion: read.dispersion,
    rounds: parsed.data.rounds,
    games: parsed.data.games,
    spread: parsed.data.spread,
  });
}

function pick(d: JudgeLadderDesignT): JudgeLadderDesignT {
  return { rounds: d.rounds, games: d.games, spread: d.spread };
}

/**
 * Read the ladder a bundle seals under the competition's directory (cli/grade-local.ts, cli/kit.ts): readJudgeLadder of
 * judge.ladder.dir and judge.dir there.
 */
export function readJudgeLadderDir(compDir: string, judge: ProgramJudgeT): JudgeLadderInputs | { refused: string } {
  if (judge.ladder === undefined) return { refused: 'the bundle names no ladder (harness.judge.ladder)' };
  return readJudgeLadder(join(compDir, ...judge.ladder.dir.split('/')), judge, join(compDir, ...judge.dir.split('/')));
}

type Kind = 'file' | 'dir' | 'other' | 'missing';

function kindOf(path: string): Kind {
  try {
    const s = lstatSync(path);
    return s.isFile() ? 'file' : s.isDirectory() ? 'dir' : 'other';
  } catch {
    return 'missing';
  }
}

/** The regular files flat under `dir`, in code-unit order of their names, read; `refused` on anything else there. */
function readFlat(dir: string, what: string, artifacts: Map<string, Uint8Array>): JudgeLadderFileT[] | { refused: string } {
  const out: JudgeLadderFileT[] = [];
  for (const file of readdirSync(dir).sort(compareCodeUnits)) {
    if (kindOf(join(dir, file)) !== 'file') return { refused: `${what}/${file} is not a regular file: every entry of ${what}/ is an artifact` };
    const bytes = new Uint8Array(readFileSync(join(dir, file)));
    const sha = sha256Hex(bytes);
    artifacts.set(sha, bytes);
    out.push({ file, artifact_sha256: sha, artifact_bytes: bytes.byteLength });
  }
  return out;
}

/** The tree digest of `dir`, or why it does not read (a missing path, a link, a device: TreeDigestError). */
function digestOf(dir: string): { sha: string } | { error: string } {
  try {
    return { sha: treeSha256(dir) };
  } catch (err) {
    // A missing path, a link or a device (TreeDigestError), or a directory the process cannot list (an errno).
    if (err instanceof TreeDigestError || (err instanceof Error && typeof (err as NodeJS.ErrnoException).code === 'string')) return { error: err.message };
    throw err;
  }
}

/**
 * Read the ladder a bundle seals at `ladderDir` (the header), with its judge directory at `judgeDir` (where
 * grader/worker.ts readJudgeTree finds it: the competition's directory, or a sponsored judged-artifact competition's
 * materialized one): each held to its tree digest, the layout, the calibration record and its hold on this judge, then
 * the fit. `refused`, saying why, when the bundle names no ladder, either directory does not read or is another one,
 * or the ladder does not hold.
 */
export function readJudgeLadder(ladderDir: string, judge: ProgramJudgeT, judgeDir: string): JudgeLadderInputs | { refused: string } {
  const sealed = judge.ladder;
  if (sealed === undefined) return { refused: 'the bundle names no ladder (harness.judge.ladder)' };
  const where = `the ladder directory ${sealed.dir}`;

  // The seals: the ladder's own, and the judge directory's its anchors are read from.
  const ladderDigest = digestOf(ladderDir);
  if ('error' in ladderDigest) return { refused: `${where} does not read (${ladderDigest.error}): the image holds no ladder for this bundle` };
  if (ladderDigest.sha !== sealed.ladder_sha256) {
    return { refused: `${where} hashes to ${ladderDigest.sha}, and the bundle seals ${sealed.ladder_sha256}: the image holds another ladder than the bundle's` };
  }
  const judgeDigest = digestOf(judgeDir);
  if ('error' in judgeDigest) return { refused: `the judge directory ${judge.dir} does not read (${judgeDigest.error}): the image holds no judge for this bundle` };
  if (judgeDigest.sha !== judge.judge_sha256) {
    return { refused: `the judge directory ${judge.dir} hashes to ${judgeDigest.sha}, and the bundle seals ${judge.judge_sha256}: the image holds another judge than the bundle's` };
  }

  // The layout: calibration.json and at most rungs/ beside it.
  const holds = `${where} holds ${PROGRAM_JUDGE_LADDER_CALIBRATION}, the house's calibration record, and at most ${PROGRAM_JUDGE_LADDER_RUNGS_DIR}/ beside it, a flat directory of house rungs`;
  for (const name of readdirSync(ladderDir).sort(compareCodeUnits)) {
    if (name !== PROGRAM_JUDGE_LADDER_CALIBRATION && name !== PROGRAM_JUDGE_LADDER_RUNGS_DIR) return { refused: `${sealed.dir}/${name} is neither ${PROGRAM_JUDGE_LADDER_CALIBRATION} nor ${PROGRAM_JUDGE_LADDER_RUNGS_DIR}/: ${holds}` };
  }
  const calibrationPath = join(ladderDir, PROGRAM_JUDGE_LADDER_CALIBRATION);
  if (kindOf(calibrationPath) !== 'file') return { refused: `${sealed.dir}/${PROGRAM_JUDGE_LADDER_CALIBRATION} is not a regular file: ${holds}` };

  const artifacts = new Map<string, Uint8Array>();
  const anchorsDir = join(judgeDir, PROGRAM_JUDGE_ANCHORS_DIR);
  if (kindOf(anchorsDir) !== 'dir') return { refused: `the judge directory ${judge.dir} has no ${PROGRAM_JUDGE_ANCHORS_DIR}/: the ladder's members are its anchors and the rungs` };
  const anchors = readFlat(anchorsDir, `${judge.dir}/${PROGRAM_JUDGE_ANCHORS_DIR}`, artifacts);
  if (!Array.isArray(anchors)) return anchors;
  const anchorShas = new Set(anchors.map((a) => a.artifact_sha256));
  const rungsDir = join(ladderDir, PROGRAM_JUDGE_LADDER_RUNGS_DIR);
  const rungsKind = kindOf(rungsDir);
  if (rungsKind !== 'missing' && rungsKind !== 'dir') return { refused: `${sealed.dir}/${PROGRAM_JUDGE_LADDER_RUNGS_DIR} is not a directory: ${holds}` };
  const rungs = rungsKind === 'missing' ? [] : readFlat(rungsDir, `${sealed.dir}/${PROGRAM_JUDGE_LADDER_RUNGS_DIR}`, artifacts);
  if (!Array.isArray(rungs)) return rungs;
  const seen = new Map<string, string>();
  for (const r of rungs) {
    const at = `${sealed.dir}/${PROGRAM_JUDGE_LADDER_RUNGS_DIR}/${r.file}`;
    if (anchorShas.has(r.artifact_sha256)) return { refused: `${at} is the same artifact as a judge anchor: a rung is a member of the ladder apart from the anchors` };
    const twin = seen.get(r.artifact_sha256);
    if (twin !== undefined) return { refused: `${at} is the same artifact as ${sealed.dir}/${PROGRAM_JUDGE_LADDER_RUNGS_DIR}/${twin}: identical rungs are one member of the ladder` };
    seen.set(r.artifact_sha256, r.file);
  }

  // The record: a v3 calibration that holds, stored as its canonical JSON.
  const bytes = new Uint8Array(readFileSync(calibrationPath));
  const recordAt = `${sealed.dir}/${PROGRAM_JUDGE_LADDER_CALIBRATION}`;
  let calibration: JudgeHeatRecordT;
  try {
    calibration = parseJudgeHeatRecord(bytes);
  } catch (err) {
    if (err instanceof JudgeHeatError) return { refused: `${recordAt}: ${err.message}` };
    throw err;
  }
  if (calibration.format !== JUDGE_HEAT_FORMAT_V3) return { refused: `${recordAt} is a ${calibration.format} record: a ladder's calibration is ${JUDGE_HEAT_FORMAT_V3}` };
  if (calibration.stage !== 'calibration') return { refused: `${recordAt} is a ${calibration.stage} heat's record: a ladder's is a calibration's` };
  const canonical = judgeHeatRecordDigest(calibration);
  if (Buffer.compare(Buffer.from(bytes), Buffer.from(canonical.json, 'utf8')) !== 0) {
    return { refused: `${recordAt} is not its record's canonical JSON (sha256 ${sha256Hex(bytes)}, the canonical form's ${canonical.sha256}): the ladder seals the record as stored` };
  }

  // This judge's: its agent, its judge directory, its media and its artifact, and a field of its anchors and these rungs.
  const off: string[] = [];
  if (canonicalJson(calibration.agent) !== canonicalJson(judge.agent)) off.push(`agent ${canonicalJson(calibration.agent)}, not the bundle's ${canonicalJson(judge.agent)}`);
  if (calibration.judge_sha256 !== judge.judge_sha256) off.push(`judge_sha256 ${calibration.judge_sha256}, not the bundle's ${judge.judge_sha256}`);
  if (calibration.media !== judge.media) off.push(`media ${calibration.media}, not the bundle's ${judge.media}`);
  if (calibration.artifact !== judge.artifact) off.push(`artifact ${calibration.artifact}, not the bundle's ${judge.artifact}`);
  const field = judgeHeatField([], anchors, rungs);
  if (canonicalJson(calibration.field) !== canonicalJson(field)) {
    off.push(`a field of ${calibration.field.length} members other than the judge's ${anchors.length} anchors and the ladder's ${rungs.length} rungs (each member's sha256, bytes, anchor files and rung files)`);
  }
  if (off.length > 0) return { refused: `${recordAt} calibrates another judge than the bundle's: ${off.join('; ')}` };

  let fit: ReturnType<typeof judgeLadderFitOf>;
  try {
    fit = judgeLadderFitOf(calibration);
  } catch (err) {
    if (err instanceof JudgeHeatError) return { refused: `${recordAt}: ${err.message}` };
    throw err;
  }
  const read = { ladder_sha256: ladderDigest.sha, calibration_sha256: canonical.sha256, strengths: fit.strengths, dispersion: fit.dispersion };
  return {
    ...read,
    anchors,
    rungs,
    members: calibration.field,
    artifacts,
    calibration,
    ladder: judgeLadderBlock(read, sealed),
  };
}
